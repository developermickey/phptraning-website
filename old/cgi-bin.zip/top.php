<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<table width="1000" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td width="127"><a href="index.php"><img src="images/logo.png" width="220" height="80" /></a></td>
    <td width="872" align="left" valign="middle"><table width="827" align="left" cellpadding="0" cellspacing="0">
      <tr>
        <td width="473">&nbsp;</td>
        <td width="352"><table width="250" align="right" cellpadding="1" cellspacing="1">
          <tr>
            <td><!--<table width="250" cellspacing="0" cellpadding="0">
              <tr>
                <td width="28%"><strong class="cont_hd">A Unit of :</strong></td>
                <td width="72%"><img src="images/logo_p.png" width="100" height="59" /></td>
              </tr>
            </table>--></td>
          </tr>
          <tr>
            <td><table width="250" cellspacing="0" cellpadding="0">
              <tr>
              <td><a href="https://www.instamojo.com/@nvironconsultingpvtltd/?ref=onb_tasks" target="_blank"><img src="images/paynow.png" alt="Pay Online" /></a></td>
                <!--<td width="14%"><img src="images/call_us.png" width="24" height="24" /></td>
                <td width="86%" class="cont_hd"><strong > +91 - 0674 - 6055501 - 02</strong></td>-->
              </tr>
            </table></td>
          </tr>
        </table></td>
      </tr>
    </table></td>
  </tr>
</table>
</body>
</html>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Pragma" content="no-cache"/>
<meta name="copyright" content="Copyright � 2014 Nviron knowledge solution, Bhubaneswar,Odisha,India"/>
<meta name="ROBOTS" content="index,follow"/> 
<meta name="revisit-after" content="15 days"/> 
<meta name="document-classification" content="Nviron knowledge solution, Bhubaneswar,Odisha,India"/>
<meta name="publisher" content="Nviron knowledge solution, Bhubaneswar,Odisha,India"/> 
<meta name="author" content="nviron.in "/> 
<meta name="copyright" content="nviron.in"/> 
<meta name="language" content="en-us"/> 
<meta name="distribution" content="GLOBAL"/> 
<meta name="geo.region" content="INDIA"/> 
<meta name="geo.placename" content="Odisha"/> 
<meta name="rating" content="General"/> 
<meta http-equiv="X-UA-Compatible" content="IE=EmulateIE8"/>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1"/>
<meta name="robots" content="INDEX, FOLLOW"/>
<meta name="generator" content="http://www.nviron.in"/>
<title>Home - NVIRON Training Centre:: Training and knowledge solution provider in the field of environment, health & safety</title>
<meta name="description" content="NVIRON Training Center is INDIA basied training and knowledge solution provider in the field of environment, health & safety" />
<meta name="keywords" content="knowledge solution provider, environmental Training Solution Provideer, Health Safety & Environment, Consultancy and Training,Training on Environment Management Plan,Training on ETP Design, Operation & Maintenance,Training on STP Design, Operation & Maintenance,Training Workshop on Rain Water Harvesting & Ground Water Management,Training Workshop on Industrial & Municipal Water Reuse & Recycle,Training on water quality monitoring & testing,Training on Drinking Water Management ,Training on Sewerage Treatment,	Training on 24*7 Water Supply,Training on RO UF design, operation & maintenance,Training on Solid Waste Management,Training on coke oven & coal gasifiers effluent treatment,Training on Air Pollution Concerning in EIA Process,Training on Air Pollution Control Technology from Industrial Activities,	Training on Carbon Foot printing and Carbon Disclosure,Training on Cleaner and Sustainable Production,Training on Industrial & Environment Waste Management,Training on Management of Major Emergencies for Control Rooms,Training on Pollution Controls in the Oil & Gas Industry" />
<link href="images/favicon.png" rel="icon" />
<link rel="stylesheet" type="text/css" href="style.css" />
<link rel="stylesheet" href="menu/menu_styles.css" type="text/css" />
<script type="text/javascript" src="menu/script.js"></script>
</head>
<body>
<table width="100%" cellspacing="0" cellpadding="0">
  <tr>
    <td height="113" align="center" background="images/top_bg.jpg" bgcolor="#FFFFFF"><?php include("top.php");?></td>
  </tr>
 <!-- <tr>
    <td height="7" align="right"></td>
  </tr>-->
  <tr>
    <td height="36" align="center" valign="top" background="images/menu_bg.jpg"><span style="background:url(images/menu_mid.jpg) repeat-x;">
      <?php include("menu.php");?>
    </span></td>
  </tr>
  <tr>
    <td height="300" align="right" valign="top"><table width="1010" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td bgcolor="#FFFFFF"><table width="995" border="0" align="center" cellpadding="0" cellspacing="0">
          <tr>
          
   <td width="995" valign="top"><iframe src="banner.html" width="995px" height="287px" scrolling="No" frameborder="" allowtransparency="true"></iframe></td>
      
          </tr>
          <tr>
            <td align="center" valign="top"><img src="images/bk_shadow_slider.png" width="956" height="14" /></td>
          </tr>
          <?php if($_GET['strmsg']){ ?>
          <?php   } ?>
        </table></td>
      </tr>
    </table></td>
  </tr>
  
  <tr>
    <td ><table width="1010" align="center" cellpadding="0" cellspacing="0" class="bx_shds">
      <tr>
        <td valign="top" bgcolor="#F8F8F8"><table width="995" border="0" align="center" cellpadding="0" cellspacing="0">
          <tr>
            <td height="5" bgcolor="#F8F8F8"></td>
          </tr>
          <tr>
            <td height="40" bgcolor="#F8F8F8"><table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
              <tr>
                <td width="22%" valign="top"><table width="204" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td height="434" valign="top" background="images/left.jpg" bgcolor="#F8F8F8"><table width="204" border="0" cellspacing="0" cellpadding="0">
                        <tr>
                          <td height="222" valign="top"><span style="background:url(images/menu_mid.jpg) repeat-x;">
                            <?php include("news.php");?>
                          </span></td>
                        </tr>
                        <tr>
                          <td><span style="background:url(images/menu_mid.jpg) repeat-x;">
                            <?php include("testimonials.php");?>
                          </span></td>
                        </tr>
                    </table></td>
                  </tr>
                  <tr>
                    <td>&nbsp;</td>
                  </tr>
                </table></td>
                <td width="59%" valign="top"><table width="578" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td height="30" class="h1">Courses Registration</td>
                  </tr>
                  <tr>
                    <td><div align="justify"><strong>You can register for a course by using one of the following means</strong><br />
                            <img src="images/arrow.jpg" width="7" height="10" /> Visit the training section of our website at www.nviron.in and complete an on-line course application form.<br />
                            <img src="images/arrow.jpg" width="7" height="10" /> Request a registration form by contacting our office using the information below.</div></td>
                  </tr>
                  <tr>
                    <td height="30"><strong class="h1">Guidelines</strong></td>
                  </tr>
                  <tr>
                    <td><div align="justify"><img src="images/arrow.jpg" width="7" height="10" /> Registration for a course ends one week prior to the commencement of the course. On receipt of duly completed registration form, an invoice will be raised for payment.<br />
                            <img src="images/arrow.jpg" width="7" height="10" /> Fees indicated are inclusive of course material, stationery, course certificate, lunch and coffee breaks. Fees are exclusive of accommodation. All fees are VAT exclusive and must be paid in full no later than one week to the commencement of the course. No participant will be admitted to a course without having paid fees in full.<br />
                            <img src="images/arrow.jpg" width="7" height="10" /> Where a course is under-subscribed, we reserve the right to re-schedule or cancel the course. Where a course is re-scheduled, registered participants will have their registration automatically transferred to the new course date. If the new date is inconvenient for a registered and paid up participant, a full refund of the course fee will be made. A full refund will also apply when a course is cancelled.<br />
                            <img src="images/arrow.jpg" width="7" height="10" /> Any registered participant who withdraws four or more weeks in advance of a course will receive a full refund. Withdrawals two weeks before will receive a 50% refund. Any withdrawals within seven days of a course are not refundable and participants will be liable for the course fee in full.<br />
                            <img src="images/arrow.jpg" width="7" height="10" /> Early Bird Discount: Full payments made four weeks or earlier to the commencement attract a 5% discount.<br />
                            <img src="images/arrow.jpg" width="7" height="10" /> Any organization registering five or more persons on a particular course will attract a 10% discount on the fifth and subsequent persons. This does not apply where a course is being specifically contracted by an organization to be run in-house.<br />
                            <img src="images/arrow.jpg" width="7" height="10" /> Joining instructions including venue location are sent at least ten days before the course.<br />
                            <img src="images/arrow.jpg" width="7" height="10" /> All delegates are provided with comprehensive materials and handouts. Please note that all materials are copyrighted and may not be reproduced without consent.<br />
                            <img src="images/arrow.jpg" width="7" height="10" /> Although details are correct going to print, we reserve the right to make unavoidable changes to the training calendar.</div>
                        </div></td>
                  </tr>
                </table></td>
                <td width="5%" valign="top" bgcolor="#F8F8F8"><span style="background:url(images/menu_mid.jpg) repeat-x;">
                  <?php include("quickenquiry.php");?>
                </span></td>
                <td width="19%" valign="top">&nbsp;</td>
              </tr>
            </table></td>
          </tr>
          
          <tr>
            <td  height="35" align="center"><img src="images/divider.jpg" width="558" height="11" /></td>
          </tr>
          <?php /*?><tr>
            <td  height="35"><?php include("pannel.php");?></td>
          </tr><?php */?>
          <tr>
            <td  height="35"><?php include("client.php");?></td>
          </tr>
          
          <tr>
            <td  height="35">&nbsp;</td>
          </tr>
          
        </table></td>
      </tr>
    </table></td>
  </tr>
  
  
  
  <tr>
    <td height="45" align="center" bgcolor="#494949"><?php include("footer.php");?></td>
  </tr>
</table>

<div id="followbuttons">
  <?php include("fblink.php");?>
</div>

</body>
</html>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Pragma" content="no-cache"/>
<meta name="copyright" content="Copyright � 2014 Nviron knowledge solution, Bhubaneswar,Odisha,India"/>
<meta name="ROBOTS" content="index,follow"/> 
<meta name="revisit-after" content="15 days"/> 
<meta name="document-classification" content="Nviron knowledge solution, Bhubaneswar,Odisha,India"/>
<meta name="publisher" content="Nviron knowledge solution, Bhubaneswar,Odisha,India"/> 
<meta name="author" content="nviron.in "/> 
<meta name="copyright" content="nviron.in"/> 
<meta name="language" content="en-us"/> 
<meta name="distribution" content="GLOBAL"/> 
<meta name="geo.region" content="INDIA"/> 
<meta name="geo.placename" content="Odisha"/> 
<meta name="rating" content="General"/> 
<meta http-equiv="X-UA-Compatible" content="IE=EmulateIE8"/>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1"/>
<meta name="robots" content="INDEX, FOLLOW"/>
<meta name="generator" content="http://www.nviron.in"/>
<title>Home - NVIRON Training Centre:: Training and knowledge solution provider in the field of environment, health & safety</title>
<meta name="description" content="NVIRON Training Center is INDIA basied training and knowledge solution provider in the field of environment, health & safety" />
<meta name="keywords" content="knowledge solution provider, environmental Training Solution Provideer, Health Safety & Environment, Consultancy and Training,Training on Environment Management Plan,Training on ETP Design, Operation & Maintenance,Training on STP Design, Operation & Maintenance,Training Workshop on Rain Water Harvesting & Ground Water Management,Training Workshop on Industrial & Municipal Water Reuse & Recycle,Training on water quality monitoring & testing,Training on Drinking Water Management ,Training on Sewerage Treatment,	Training on 24*7 Water Supply,Training on RO UF design, operation & maintenance,Training on Solid Waste Management,Training on coke oven & coal gasifiers effluent treatment,Training on Air Pollution Concerning in EIA Process,Training on Air Pollution Control Technology from Industrial Activities,	Training on Carbon Foot printing and Carbon Disclosure,Training on Cleaner and Sustainable Production,Training on Industrial & Environment Waste Management,Training on Management of Major Emergencies for Control Rooms,Training on Pollution Controls in the Oil & Gas Industry" />
<link href="images/favicon.png" rel="icon" />
<link rel="stylesheet" type="text/css" href="style.css" />
<link rel="stylesheet" href="menu/menu_styles.css" type="text/css" />
<script type="text/javascript" src="menu/script.js"></script>
</head>
<body>
<table width="100%" cellspacing="0" cellpadding="0">
  <tr>
    <td height="113" align="center" background="images/top_bg.jpg" bgcolor="#FFFFFF"><?php include("top.php");?></td>
  </tr>
 <!-- <tr>
    <td height="7" align="right"></td>
  </tr>-->
  <tr>
    <td height="36" align="center" valign="top" background="images/menu_bg.jpg" ><span style="background:url(images/menu_mid.jpg) repeat-x;">
      <?php include("menu.php");?>
    </span></td>
  </tr>
  <tr>
    <td height="300" align="right" valign="top"><table width="1010" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td bgcolor="#FFFFFF"><table width="995" border="0" align="center" cellpadding="0" cellspacing="0">
          <tr>
          
   <td width="995" valign="top"><iframe src="banner.html" width="995px" height="287px" scrolling="No" frameborder="" allowtransparency="true"></iframe></td>
      
          </tr>
          <tr>
            <td align="center" valign="top"><img src="images/bk_shadow_slider.png" width="956" height="14" /></td>
          </tr>
          <?php if($_GET['strmsg']){ ?>
          <?php   } ?>
        </table></td>
      </tr>
    </table></td>
  </tr>
  
  <tr>
    <td ><table width="1010" align="center" cellpadding="0" cellspacing="0" class="bx_shds">
      <tr>
        <td valign="top" bgcolor="#F8F8F8"><table width="995" border="0" align="center" cellpadding="0" cellspacing="0">
          <tr>
            <td height="5" bgcolor="#F8F8F8"></td>
          </tr>
          
          <tr>
            <td  height="35"><table width="995" border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td width="21%" valign="top"  bgcolor="#F8F8F8"><table width="204" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td height="222" valign="top" background="images/left.jpg"><span style="background:url(images/menu_mid.jpg) repeat-x;">
                      <?php include("news.php");?>
                    </span></td>
                  </tr>
                  <tr>
                    <td background="images/left.jpg"><span style="background:url(images/menu_mid.jpg) repeat-x;">
                      <?php include("testimonials.php");?>
                    </span></td>
                  </tr>
                </table></td>
                <td valign="top" bgcolor="#F8F8F8"><table width="573" border="0" align="center" cellpadding="0" cellspacing="0">
                  <tr>
                    <td><table width="578" border="0" align="center" cellpadding="0" cellspacing="0">
                      <tr>
                        <td height="30" class="h1">Courses</td>
                      </tr>
                      <tr>
                        <td><div align="justify"><img src="images/arrow.jpg" width="7" height="10" /> Training on Environment Management Plan<br />
                       <img src="images/arrow.jpg" width="7" height="10" /> Training on Detailed designing of ETP/STP<br />
                                <img src="images/arrow.jpg" width="7" height="10" /> Training on ETP Design, Operation &amp; Maintenance <br />
                                <img src="images/arrow.jpg" width="7" height="10" /> Training on STP Design, Operation &amp; Maintenance<br />
                                <img src="images/arrow.jpg" width="7" height="10" /> Training Workshop on Rain Water Harvesting &amp; Ground Water Management<br />
                                <img src="images/arrow.jpg" width="7" height="10" /> Training Workshop on Industrial &amp; Municipal Water Reuse &amp; Recycle<br />
                                <img src="images/arrow.jpg" width="7" height="10" /> Training on water quality monitoring &amp; testing<br />
                                <img src="images/arrow.jpg" width="7" height="10" /> Training on Drinking Water Management<br />
                                <img src="images/arrow.jpg" width="7" height="10" /> Training on Sewerage Treatment<br />
                                <img src="images/arrow.jpg" width="7" height="10" border="0" /> Training on 24*7 Water Supply<br />
                                <img src="images/arrow.jpg" width="7" height="10" /> Training on RO UF design, operation &amp; maintenance <br />
                                <img src="images/arrow.jpg" width="7" height="10" /> Training on Solid Waste Management<br />
                                <img src="images/arrow.jpg" width="7" height="10" /> Training on coke oven &amp; coal gasifiers effluent treatment<br />
                                <img src="images/arrow.jpg" width="7" height="10" /> Training on Air Pollution Concerning in EIA Process<br />
                                <img src="images/arrow.jpg" width="7" height="10" /> Training on Air Pollution Control Technology from Industrial Activities<br />
                                <img src="images/arrow.jpg" width="7" height="10" /> Training on Carbon Foot printing and Carbon Disclosure<br />
                                <img src="images/arrow.jpg" width="7" height="10" /> Training on Cleaner and Sustainable Production<br />
                                <img src="images/arrow.jpg" width="7" height="10" /> Training on Industrial &amp; Environment Waste Management<br />
                                <img src="images/arrow.jpg" width="7" height="10" /> Training on Management of Major Emergencies for Control Rooms<br />
                                <img src="images/arrow.jpg" width="7" height="10" /> Training on Pollution Controls in the Oil &amp; Gas Industry </div>
                                
                                <div align="justify"><br />
                                - <strong>Legal</strong><br />
<img src="images/arrow.jpg" width="7" height="10" />Indian Environmental Regulations & Case Laws <br />
<img src="images/arrow.jpg" width="7" height="10" />Contract Drafting & Dispute Resolutions<br />
<img src="images/arrow.jpg" width="7" height="10" />alternative dispute resolution<br /><br />
<strong>-Corporate Leadership Development </strong><br />
<img src="images/arrow.jpg" width="7" height="10" />	Leadership skills training <br />
<img src="images/arrow.jpg" width="7" height="10" />	Action centered leadership <br />
<img src="images/arrow.jpg" width="7" height="10" /> EQ  for business leaders <br />
<img src="images/arrow.jpg" width="7" height="10" />	Coaching & Mentoring<br /><br />
<strong>-Team work </strong><br />
<img src="images/arrow.jpg" width="7" height="10" />	Team bonding program <br />
<img src="images/arrow.jpg" width="7" height="10" />	Team building training <br />
<img src="images/arrow.jpg" width="7" height="10" /> Team management training<br /><br />
<strong>-Executive development</strong> <br />
<img src="images/arrow.jpg" width="7" height="10" /> Communication skills workshop<br /> 
<img src="images/arrow.jpg" width="7" height="10" />	People smart - subordinate development program<br />
<img src="images/arrow.jpg" width="7" height="10" />	Change management <br />
<img src="images/arrow.jpg" width="7" height="10" />	Time management <br />
<img src="images/arrow.jpg" width="7" height="10" />	Work smart re-engineering work practices <br />
<img src="images/arrow.jpg" width="7" height="10" />	Work life balance <br />
<img src="images/arrow.jpg" width="7" height="10" />	Winning ways -the attitude workshop <br />
<img src="images/arrow.jpg" width="7" height="10" />	Goal setting & action planning <br />
<img src="images/arrow.jpg" width="7" height="10" />	Planning & organizing <br />
<img src="images/arrow.jpg" width="7" height="10" />	Advanced communication for action & results <br />
<img src="images/arrow.jpg" width="7" height="10" />Vision management & core value actualization<br />
<img src="images/arrow.jpg" width="7" height="10" />	The purposeful manager <br /><br />
<strong>-Managerial effectiveness </strong><br />
<img src="images/arrow.jpg" width="7" height="10" />	Conflict resolution & management <br />
<img src="images/arrow.jpg" width="7" height="10" />	Problem solving & decision making <br />
<img src="images/arrow.jpg" width="7" height="10" />	Hr for line managers <br />
<img src="images/arrow.jpg" width="7" height="10" />	Performance management <br />
<img src="images/arrow.jpg" width="7" height="10" />	Effective meeting skills <br />
<img src="images/arrow.jpg" width="7" height="10" />	People smart - subordinate development program<br />
<img src="images/arrow.jpg" width="7" height="10" />	Customer service management <br />
<img src="images/arrow.jpg" width="7" height="10" />	Customer delight <br />
<img src="images/arrow.jpg" width="7" height="10" />	Effective delegation <br />
<img src="images/arrow.jpg" width="7" height="10" />	Facilitative management<br />
<img src="images/arrow.jpg" width="7" height="10" />	Work life balance for women employees<br />

                                </div>
                                
                                
                                </td>
                      </tr>
                    </table></td>
                  </tr>
                </table></td>
                <td width="5%" valign="top" bgcolor="#F8F8F8"><span style="background:url(images/menu_mid.jpg) repeat-x;">
                  <?php include("quickenquiry.php");?>
                </span></td>
              </tr>
            </table></td>
          </tr>
          <tr>
            <td  height="35" align="center"><img src="images/divider.jpg" width="558" height="11" /></td>
          </tr>
         <?php /*?> <tr>
            <td  height="35"><?php include("pannel.php");?></td>
          </tr><?php */?>
          <tr>
            <td  height="35"><?php include("client.php");?></td>
          </tr>
          
          <tr>
            <td  height="35">&nbsp;</td>
          </tr>
          
        </table></td>
      </tr>
    </table></td>
  </tr>
  
  
  
  <tr>
    <td height="45" align="center" bgcolor="#494949"><?php include("footer.php");?></td>
  </tr>
</table>

<div id="followbuttons">
  <?php include("fblink.php");?>
</div>

</body>
</html>

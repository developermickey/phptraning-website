<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Pragma" content="no-cache"/>
<meta name="copyright" content="Copyright � 2014 Nviron knowledge solution, Bhubaneswar,Odisha,India"/>
<meta name="ROBOTS" content="index,follow"/> 
<meta name="revisit-after" content="15 days"/> 
<meta name="document-classification" content="Nviron knowledge solution, Bhubaneswar,Odisha,India"/>
<meta name="publisher" content="Nviron knowledge solution, Bhubaneswar,Odisha,India"/> 
<meta name="author" content="nviron.in "/> 
<meta name="copyright" content="nviron.in"/> 
<meta name="language" content="en-us"/> 
<meta name="distribution" content="GLOBAL"/> 
<meta name="geo.region" content="INDIA"/> 
<meta name="geo.placename" content="Odisha"/> 
<meta name="rating" content="General"/> 
<meta http-equiv="X-UA-Compatible" content="IE=EmulateIE8"/>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1"/>
<meta name="robots" content="INDEX, FOLLOW"/>
<meta name="generator" content="http://www.nviron.in"/>
<title>Home - NVIRON Training Centre:: Training and knowledge solution provider in the field of environment, health & safety</title>
<meta name="description" content="NVIRON Training Center is INDIA basied training and knowledge solution provider in the field of environment, health & safety" />
<meta name="keywords" content="knowledge solution provider, environmental Training Solution Provideer, Health Safety & Environment, Consultancy and Training,Training on Environment Management Plan,Training on ETP Design, Operation & Maintenance,Training on STP Design, Operation & Maintenance,Training Workshop on Rain Water Harvesting & Ground Water Management,Training Workshop on Industrial & Municipal Water Reuse & Recycle,Training on water quality monitoring & testing,Training on Drinking Water Management ,Training on Sewerage Treatment,	Training on 24*7 Water Supply,Training on RO UF design, operation & maintenance,Training on Solid Waste Management,Training on coke oven & coal gasifiers effluent treatment,Training on Air Pollution Concerning in EIA Process,Training on Air Pollution Control Technology from Industrial Activities,	Training on Carbon Foot printing and Carbon Disclosure,Training on Cleaner and Sustainable Production,Training on Industrial & Environment Waste Management,Training on Management of Major Emergencies for Control Rooms,Training on Pollution Controls in the Oil & Gas Industry" />
<link href="images/favicon.png" rel="icon" />
<link rel="stylesheet" type="text/css" href="style.css" />
<link rel="stylesheet" href="menu/menu_styles.css" type="text/css" />
<script type="text/javascript" src="menu/script.js"></script>
</head>
<body>
<table width="100%" cellspacing="0" cellpadding="0">
  <tr>
    <td height="113" align="center" background="images/top_bg.jpg" bgcolor="#FFFFFF"><?php include("top.php");?></td>
  </tr>
 <!-- <tr>
    <td height="7" align="right"></td>
  </tr>-->
  <tr>
    <td height="36" align="center" valign="top" background="images/menu_bg.jpg"><span style="background:url(images/menu_mid.jpg) repeat-x;">
      <?php include("menu.php");?>
    </span></td>
  </tr>
  <tr>
    <td height="300" align="right" valign="top"><table width="1010" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td bgcolor="#FFFFFF"><table width="995" border="0" align="center" cellpadding="0" cellspacing="0">
          <tr>
          
   <td width="995" valign="top"><iframe src="banner.html" width="995px" height="287px" scrolling="No" frameborder="" allowtransparency="true"></iframe></td>
      
          </tr>
          <tr>
            <td align="center" valign="top"><img src="images/bk_shadow_slider.png" width="956" height="14" /></td>
          </tr>
          <?php if($_GET['strmsg']){ ?>
          <?php   } ?>
        </table></td>
      </tr>
    </table></td>
  </tr>
  
  <tr>
    <td ><table width="1010" align="center" cellpadding="0" cellspacing="0" class="bx_shds">
      <tr>
        <td valign="top" bgcolor="#F8F8F8"><table width="995" border="0" align="center" cellpadding="0" cellspacing="0">
          <tr>
            <td height="5" bgcolor="#F8F8F8"></td>
          </tr>
          <tr>
            <td height="40" bgcolor="#F8F8F8"><table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
              <tr>
                <td width="22%" valign="top"><table width="204" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td height="434" valign="top" background="images/left.jpg" bgcolor="#F8F8F8"><table width="204" border="0" cellspacing="0" cellpadding="0">
                        <tr>
                          <td height="222" valign="top"><span style="background:url(images/menu_mid.jpg) repeat-x;">
                            <?php include("news.php");?>
                          </span></td>
                        </tr>
                        <tr>
                          <td><span style="background:url(images/menu_mid.jpg) repeat-x;">
                            <?php include("testimonials.php");?>
                          </span></td>
                        </tr>
                    </table></td>
                  </tr>
                  <tr>
                    <td>&nbsp;</td>
                  </tr>
                </table></td>
                <td width="59%" valign="top"><table width="578" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td height="30" class="h1">Contact Us</td>
                  </tr>
                  <tr>
                    <td><table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
                      <tr>
                        <td width="44%" valign="top"><strong>Registered Office</strong><br />
                         House No- 168/C/757,<span style="display:block"></span> Baghamangala Lane, Mangalabag,<span style="display:block"></span> Cuttack-753001</td>
                        <td width="56%" rowspan="3" align="center" valign="top"><img src="images/contact.jpg" alt="contact" width="315" height="169" /></td>
                      </tr>
                      <tr>
                        <td valign="top">&nbsp;</td>
                        </tr>
                      <tr>
                        <td valign="top"><strong>Corporate Office</strong><br />
                          Plot No. 1610,<span style="display:block"></span> Mahanadi Vihar, Cuttack - 753004,<span style="display:block"></span> Telefax: 0671-244-2028</td>
                        </tr>
                        <tr>
                        <td><strong style="color:#f00;font-size:15px;">CIN: U74999OR2017PTC026279</strong></td>
                        </tr>
                    </table></td>
                  </tr>
                  <tr>
                    <td align="center">&nbsp;</td>
                  </tr>
                  
                  
                  
                </table></td>
                <td width="5%" valign="top" bgcolor="#F8F8F8"><span style="background:url(images/menu_mid.jpg) repeat-x;">
                  <?php include("quickenquiry.php");?>
                </span></td>
                <td width="19%" valign="top">&nbsp;</td>
              </tr>
            </table></td>
          </tr>
          
          <tr>
            <td  height="35" align="center"><img src="images/divider.jpg" width="558" height="11" /></td>
          </tr>
          <?php /*?><tr>
            <td  height="35"><?php include("pannel.php");?></td>
          </tr><?php */?>
          <tr>
            <td  height="35"><?php include("client.php");?></td>
          </tr>
          
          <tr>
            <td  height="35">&nbsp;</td>
          </tr>
          
        </table></td>
      </tr>
    </table></td>
  </tr>
  
  
  
  <tr>
    <td height="45" align="center" bgcolor="#494949"><?php include("footer.php");?></td>
  </tr>
</table>

<div id="followbuttons">
  <?php include("fblink.php");?>
</div>

</body>
</html>

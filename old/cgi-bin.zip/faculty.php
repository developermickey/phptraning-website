<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Pragma" content="no-cache"/>
<meta name="copyright" content="Copyright � 2014 Nviron knowledge solution, Bhubaneswar,Odisha,India"/>
<meta name="ROBOTS" content="index,follow"/> 
<meta name="revisit-after" content="15 days"/> 
<meta name="document-classification" content="Nviron knowledge solution, Bhubaneswar,Odisha,India"/>
<meta name="publisher" content="Nviron knowledge solution, Bhubaneswar,Odisha,India"/> 
<meta name="author" content="nviron.in "/> 
<meta name="copyright" content="nviron.in"/> 
<meta name="language" content="en-us"/> 
<meta name="distribution" content="GLOBAL"/> 
<meta name="geo.region" content="INDIA"/> 
<meta name="geo.placename" content="Odisha"/> 
<meta name="rating" content="General"/> 
<meta http-equiv="X-UA-Compatible" content="IE=EmulateIE8"/>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1"/>
<meta name="robots" content="INDEX, FOLLOW"/>
<meta name="generator" content="http://www.nviron.in"/>
<title>Home - NVIRON Training Centre:: Training and knowledge solution provider in the field of environment, health & safety</title>
<meta name="description" content="NVIRON Training Center is INDIA basied training and knowledge solution provider in the field of environment, health & safety" />
<meta name="keywords" content="knowledge solution provider, environmental Training Solution Provideer, Health Safety & Environment, Consultancy and Training,Training on Environment Management Plan,Training on ETP Design, Operation & Maintenance,Training on STP Design, Operation & Maintenance,Training Workshop on Rain Water Harvesting & Ground Water Management,Training Workshop on Industrial & Municipal Water Reuse & Recycle,Training on water quality monitoring & testing,Training on Drinking Water Management ,Training on Sewerage Treatment,	Training on 24*7 Water Supply,Training on RO UF design, operation & maintenance,Training on Solid Waste Management,Training on coke oven & coal gasifiers effluent treatment,Training on Air Pollution Concerning in EIA Process,Training on Air Pollution Control Technology from Industrial Activities,	Training on Carbon Foot printing and Carbon Disclosure,Training on Cleaner and Sustainable Production,Training on Industrial & Environment Waste Management,Training on Management of Major Emergencies for Control Rooms,Training on Pollution Controls in the Oil & Gas Industry" />
<link href="images/favicon.png" rel="icon" />
<link rel="stylesheet" type="text/css" href="style.css" />
<link rel="stylesheet" href="menu/menu_styles.css" type="text/css" />
<script type="text/javascript" src="menu/script.js"></script>
</head>
<body>
<table width="100%" cellspacing="0" cellpadding="0">
  <tr>
    <td height="113" align="center" background="images/top_bg.jpg" bgcolor="#FFFFFF"><?php include("top.php");?></td>
  </tr>
 <!-- <tr>
    <td height="7" align="right"></td>
  </tr>-->
  <tr>
    <td height="36" align="center" valign="top" background="images/menu_bg.jpg" ><span style="background:url(images/menu_mid.jpg) repeat-x;">
      <?php include("menu.php");?>
    </span></td>
  </tr>
  <tr>
    <td height="300" align="right" valign="top"><table width="1010" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td bgcolor="#FFFFFF"><table width="995" border="0" align="center" cellpadding="0" cellspacing="0">
          <tr>
          
   <td width="995" valign="top"><iframe src="banner.html" width="995px" height="287px" scrolling="No" frameborder="" allowtransparency="true"></iframe></td>
      
          </tr>
          <tr>
            <td align="center" valign="top"><img src="images/bk_shadow_slider.png" width="956" height="14" /></td>
          </tr>
          <?php if($_GET['strmsg']){ ?>
          <?php   } ?>
        </table></td>
      </tr>
    </table></td>
  </tr>
  
  <tr>
    <td ><table width="1010" align="center" cellpadding="0" cellspacing="0" class="bx_shds">
      <tr>
        <td valign="top" bgcolor="#F8F8F8"><table width="995" border="0" align="center" cellpadding="0" cellspacing="0">
          <tr>
            <td height="5" bgcolor="#F8F8F8"></td>
          </tr>
          
          <tr>
            <td  height="35"><table width="995" border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td width="21%" valign="top"  bgcolor="#F8F8F8">
                <table width="204" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td height="222" valign="top" background="images/left.jpg"><span style="background:url(images/menu_mid.jpg) repeat-x;">
                      <?php include("news.php");?>
                    </span></td>
                  </tr>
                  <tr>
                    <td background="images/left.jpg"><span style="background:url(images/menu_mid.jpg) repeat-x;">
                      <?php include("testimonials.php");?>
                    </span></td>
                  </tr>
                </table></td>
                <td valign="top" bgcolor="#F8F8F8"><table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
                  <tr>
                    <td><table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
                      <tr>
                        <td height="30" class="h1">Trainers</td>
                      </tr>
                      <tr>
                        <td>
                             <table width="100%" cellpadding="1" cellspacing="1">
                                                              <colgroup><col width="64">
                                                              <col width="251">
                                                              <col width="107">
                                                              
                                                              </colgroup><style>
                                                              .blue-bg{ background: #0e6ab3;color: #fff;}
															  .gray-bg{
															      background: #eee;
															  }
															  .gray-bg-even{
															      background: #e0e0e0;
															  }
                                                              </style>
                                                              <tbody><tr height="30">
                                                                <td height="30" class="blue-bg"><strong>SL NO</strong></td>
                                                                <td width="296" class="blue-bg"><strong>NAME </strong></td>
                                                                <td class="blue-bg"><strong>INTRODUCTION</strong></td>
                                                                <td class="blue-bg"><strong>PHOTO</strong></td>
                                                              </tr>
                                                              <tr height="30">
                                                                <td height="30" class="gray-bg" align="center">1</td>
                                                                <td width="296" class="gray-bg">Mr. S Soundara Rajan</td>
                                                                <td width="319" align="justify" class="gray-bg">Mr. S Soundara Rajan is a 33 years experienced Waste water expert. He has completed B.Sc. Chemistry from Madras University and Diploma in Chemical Technology from Annamalai University. His work experience covers in project coordination, vendor development, site management, coordination with project team, inspection coordination,, Revenue, Institutional sales. OEMs and project consultants etc. Independently handled medium size project execution in ETP/STP with UF/MBR/RO technologies in Sugar Effluent treatment at Silk Road sugars -murugappa group at Kakinada and Domestic residential sewage treatment system in. Ramky Infrastructures Ltd-Guchibowli-Ramky Towers Hyderabad. Worked as a Project coordinator in India's first 100MLD Desalination Project in BOOT basis for Drinking water supply to Chennai Metro Water with JV partner Befesa-Spain.1000 cores project.
</td>
<td class="gray-bg"><img src="images/faculty/soundara-rajan.jpg"></td>
                                                              </tr>
                                                              <tr height="30">
                                                                <td height="30" class="gray-bg-even" align="center">2</td>
                                                                <td width="296" class="gray-bg-even">Mrs. Vinita Dhupkar</td>
                                                                <td width="319" align="justify" class="gray-bg-even">Masters in Environmental Science & Engineering from IIT, Mumbai with more than 34 years experience in environmental field. Hands-on professional with an expertise in both conventional, modern waste-water treatment technologies and Zero Liquid Discharge (ZLD) technologies. Worked with EPC companies, Govt. Regulatory Body, Consultancy Company as well as in teaching and training professions. Wide experience in designing WTPs as well as WWTPs envisaging diverse technologies like UASB, SBR, MBBR, MBR, ASP, Extended Aeration, etc.</td>
                                                                <td class="gray-bg-even"><img src="images/faculty/img1.jpg"></td>
                                                              </tr>
                                                              <tr height="30">
                                                                <td height="30" class="gray-bg" align="center">3</td>
                                                                <td width="296" class="gray-bg">Mr. Chetan Kale</td>
                                                                <td width="319" align="justify" class="gray-bg">Mr. Chetan Kale has 18 years of experience of increasing responsibility in the Civil & Environmental engineering profession. Dealt extensively with EPA, MWRDGC, Village of Arlington Heights, City of Columbus, and City of Chicago agencies, MPCB. Design experience included Storm sewer Modelling, Drainage design, Sanitary sewer study, Sewage Treatment plant studies, Industrial and municipal waste treatment.</td>
                                                                <td class="gray-bg"><img src="images/faculty/img2.jpg"></td>
                                                              </tr>
                                                              <tr height="30">
                                                                <td height="30" class="gray-bg-even" align="center">4</td>
                                                                <td width="296" class="gray-bg-even">Dr. Ashim Kumar Bhattacharya</td>
                                                                <td width="319" align="justify" class="gray-bg-even">More than 26 years of versatile experience in Industry, Training and Res in industrial/ Municipal Water and Effluent Treatment, Membrane Tech Applications with recycle and reuse, Fuel Management, Waste Management, ODS Phasing Out; Environmental Compliance, EH&S with Global Warming /Climate Change related issues.</td>
                                                                <td class="gray-bg-even"><img src="images/faculty/img3.jpg"></td>
                                                              </tr>
                                                              <tr height="30">
                                                                <td height="30" class="gray-bg" align="center">5</td>
                                                                <td width="296" class="gray-bg">Dr. S. Sundaramoorthy</td>
                                                                <td width="319" align="justify" class="gray-bg">is a PhD in Environmental Engineering from IIT, Madras and former Engineering Director of Chennai Metropolitan Water Supply and Sewerage Board. He has assisted the World Bank, JBIC, UNIDO, UNDP, ODA of UK; USTDA, GTZ and ASEM. He has guided sewage reuse projects for cooling water in MFL, CPCL, GMR Vasavi, New Delhi T3 and Mumbai airport and ZLD projects in textiles, tanneries, chemicals, pharmaceuticals, insecticides, pesticides, distilleries, sugar mill, pulp & paper etc. A Fellow of Royal Society for Promotion of Health, London and an invited member of the American Chemical Society, he is the first International Professional Engineer in Environmental Engineering of the Institution of Engineers, India</td>
                                                                <td class="gray-bg"><img src="images/faculty/sundaramoorthy.jpg"></td>
                                                              </tr>
                                                              <tr height="30">
                                                                <td height="30" class="gray-bg-even" align="center">6</td>
                                                                <td width="296" class="gray-bg-even">Mr. A. Manoharan</td>
                                                                <td width="319" align="justify" class="gray-bg-even">He worked as Sr. Scientist &  Zonal Officer in CPCB,in South Zonal Office, Bangalore since 2009 and got superannuation in June 2013. He joined in CPCB in 1982 and has vast experience of 31 years at various capacities and places such as Pondicherry. Delhi HQ and Bangalore Zonal Office.  While serving as Zonal officer, he was actively engaged in pollution control activities and co-ordination of five Southern States and 2 Union territories.    
At present, Mr. Manoharan is a QCI-NABET approved Functional Area Expert and project Coordinator for Environmental Impact Assessment (EIA) studies. He is serving as Environmental Scientific & Technical advisor for pollution control activities for M/s BEIL, a TSDF Hazardous waste processing unit of M/s United Phosphorous Ltd,(UPL), Gujarat 
</td>
                                                                <td class="gray-bg-even"><img src="images/faculty/manoharan.jpg"></td>
                                                              </tr>
                                                              <tr height="30">
                                                                <td height="30" class="gray-bg" align="center">7</td>
                                                                <td width="296" class="gray-bg">Dr. K. Karthikeyan</td>
                                                                <td width="319" align="justify" class="gray-bg">Former Member Secretary of Tamilnadu Pollution Control Board (Director Environmental training institute). Currently he is the Chairman of Centre of Excellence of Urban Solid Waste Management (CoEUSWM), Chennai  & Centre of Excellence Urban Air Quality Management (CoEUAQM), Chennai. He has done B.E Chemical Engg., M.Tech Environmental Engg , IIT Madras & also PhD in Environmental Science and Masters in Industrial Safety & Hygiene. Expertise in State Policy Expert, Environment Law, Waste to Energy, Bio gas Plant and Composting Technologies, Governance & Monitoring.</td>
                                                                <td class="gray-bg"><img src="images/faculty/kartikeyan.jpg"></td>
                                                              </tr>
                                                              <tr height="30">
                                                                <td height="30" class="gray-bg-even" align="center">8</td>
                                                                <td width="296" class="gray-bg-even">Dr. Dilip Boralkar</td>
                                                                <td width="319" align="justify" class="gray-bg-even">Dr. Dilip Boralkar is well known professional expert in the field of environment protection.  He has functional experience of 38 years in the field of pollution control, survey, assessment and monitoring. Presently he is Free Lance Senior Scientist and does Counseling for Environment Protection. His tenure as Member Secretary of Maharashtra Pollution Control Board and Maharashtra Coastal Zone Management Authority during 2003-2007 was remarkable due to his positive approach, transparent functioning and tough administration resulting in to the increased efficiency of the Board in terms of reduced pollution and increased revenues. He promoted public-private partnerships in the creation of common infrastructure for environmental protection.
</td>
                                                                <td class="gray-bg-even"><img src="images/faculty/dillip.jpg"></td>
                                                              </tr>
                                                          </tbody></table>
                        </td>
                      </tr>
                    </table></td>
                  </tr>
                </table></td>
                
              </tr>
            </table></td>
          </tr>
          <tr>
            <td  height="35" align="center"><img src="images/divider.jpg" width="558" height="11" /></td>
          </tr>
         <?php /*?> <tr>
            <td  height="35"><?php include("pannel.php");?></td>
          </tr><?php */?>
          <tr>
            <td  height="35"><?php include("client.php");?></td>
          </tr>
          
          <tr>
            <td  height="35">&nbsp;</td>
          </tr>
          
        </table></td>
      </tr>
    </table></td>
  </tr>
  
  
  
  <tr>
    <td height="45" align="center" bgcolor="#494949"><?php include("footer.php");?></td>
  </tr>
</table>

<div id="followbuttons">
  <?php include("fblink.php");?>
</div>

</body>
</html>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<table width="1000" border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td valign="top"><table width="290" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td valign="top" background="images/color-bg1.jpg"><table width="268" border="0" align="center" cellpadding="0" cellspacing="0">
            <tr>
              <td height="8"></td>
            </tr>
            <tr>
              <td height="32" align="center" valign="top" bgcolor="#E9E9E9" class="textwhitebold"><img src="images/img1.jpg" width="293" height="110" /></td>
            </tr>
            <tr>
              <td height="32" align="center" class="textwhitebold"><table width="293" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td width="13%"><img src="images/ico3.jpg" width="30" height="26" /></td>
                    <td width="87%" class="cont_hd"><strong>MISSION</strong></td>
                  </tr>
              </table></td>
            </tr>
            <tr>
              <td class="text_12"><div align="justify" class="content">To impart environmental training to each &amp; every organization.</div></td>
            </tr>
        </table></td>
      </tr>
    </table></td>
    <td align="center" valign="top"><table width="290" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td valign="top" background="images/color-bg3.jpg"><table width="268" border="0" align="center" cellpadding="0" cellspacing="0">
          <tr>
            <td height="8"></td>
          </tr>
          <tr>
            <td height="32" align="center" bgcolor="#E9E9E9" class="textwhitebold"><img src="images/img2.jpg" width="293" height="110" /></td>
          </tr>
          <tr>
            <td height="32" align="center" class="textwhitebold"><table width="293" border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td width="13%"><img src="images/ico3.jpg" width="30" height="26" /></td>
                <td width="87%" class="cont_hd"><strong>VISION</strong></td>
              </tr>
            </table></td>
          </tr>
          <tr>
            <td ><div align="justify">To become the best knowledge solution provider to the industries in the field of Environment, Health & Safety.</div></td>
          </tr>
        </table></td>
      </tr>
    </table></td>
    <td align="center"><table width="290" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td valign="top" background="images/color-bg2.jpg"><table width="268" border="0" align="center" cellpadding="0" cellspacing="0">
          <tr>
            <td height="8"></td>
          </tr>
          <tr>
            <td height="32" align="center" bgcolor="#E9E9E9" class="textwhitebold"><img src="images/img3.jpg" width="293" height="110" /></td>
          </tr>
          <tr>
            <td height="32" align="center" class="textwhitebold"><table width="293" border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td width="13%"><img src="images/ico3.jpg" width="30" height="26" /></td>
                <td width="87%" class="cont_hd"><strong>CSR</strong></td>
              </tr>
            </table></td>
          </tr>
          <tr>
            <td ><div align="justify">In addition to providing the training and knowledge solution on environment, Nviron seeks to contribute to the sustainable development of society. We build a better, sustainable way of life for the weaker sections of society and raise the country's human development index.We actively contribute to the social and economic development of the communities in which we operate.</div></td>
          </tr>
        </table></td>
      </tr>
    </table></td>
  </tr>
</table>
</body>
</html>

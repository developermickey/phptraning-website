<?
if($_POST[Submit])
{
$to="anupam@nviron.in";
$name=$_POST['name'];
$email=$_POST['email'];
$mob=$_POST['mob'];
$course=$_POST['course'];
$pst=$_POST['pst'];
$message=$_POST['message'];
$subject="Submit Requirement From"."".$name;
$headers = "Name"."-".$name. "\r\n" ."Email"."-". $email. "\r\n"."Mob"."-" .$mob. "\r\n"."Course"."-" .$course. "\r\n". "Pst"."-". $pst. "\r\n"."Message"."-" .$message. "\r\n";
mail($to, $subject, $headers);
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<table width="212" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td><table width="203" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td width="470" height="30" bgcolor="#FF9900"><table width="174" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td width="10">&nbsp;</td>
            <td width="164" height="30" valign="middle" class="white1">QUICK ENQUIRY</td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td bgcolor="#0e6ab3"><form id="form1" name="form1" method="post" action=""><table width="192" border="0" align="center" cellpadding="0" cellspacing="0">
          <tr>
            <td height="30" class="text_12">Name</td>
          </tr>
          <tr>
            <td><input type="text" name="name" id="textfield" /></td>
          </tr>
          <tr>
            <td><span class="text_12">Email Id</span></td>
          </tr>
          <tr>
            <td><input type="text" name="email" id="textfield2" /></td>
          </tr>
          <tr>
            <td><span class="text_12">Mobile </span></td>
          </tr>
          <tr>
            <td><input type="text" name="mob" id="textfield3" /></td>
          </tr>
          <tr>
            <td><span class="text_12">Courses</span></td>
          </tr>
          <tr>
            <td><textarea name="course" id="textfield4"></textarea></td>
          </tr>
          <tr>
            <td height="30"><span class="text_12">Planning to  start training</span></td>
          </tr>
          <tr>
            <td><input type="text" name="pst" id="textfield6" /></td>
          </tr>
          <tr>
            <td class="text_12">Message</td>
          </tr>
          <tr>
            <td><textarea name="message" rows="3" id="textfield5"></textarea></td>
          </tr>
          <tr>
            <td height="30">&nbsp;</td>
          </tr>
          <tr>
            <td>
              <input name="Submit" type="submit" class="top_cont" value="Submit"/>
          </td>
          </tr>
          <tr>
            <td>&nbsp;</td>
          </tr>
        </table></form></td>
      </tr>
    </table></td>
  </tr>
</table>
</body>
</html>

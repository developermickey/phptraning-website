<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<table width="1000" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td width="982"><ul class="menu" id="menu">
     <!-- <li><a href="index.php" class="menulink" >HOME</a></li>-->
      <li><a href="aboutus.php" class="menulink"> ABOUT US</a></li>
       <li> <a href="#" class="menulink"> COURSES</a>
       <ul>
       <li><a href="courses.php"> LIST OF COURSE </a></li>
     <li><a href="courses_registration.php">COURSE REGISTRATION</a></li>
     </ul>
     </li>
     <li><a href="faculty.php" class="menulink"> TRAINERS</a></li>     
     <li><a href="external_training.php" class="menulink"> NVIRON EXTERNAL & IN-HOUSE</a></li>
      <!--<li><a href="house_training.php" class="menulink">NVIRON IN HOUSE</a></li>-->
      <li> <a href="career.php" class="menulink">CAREER</a></li>
      <li> <a href="contact_us.php" class="menulink">CONTACT US</a></li>
    </ul>
        <script type="text/javascript">
	var menu=new menu.dd("menu");
	menu.init("menu","menuhover");
                </script></td>
  </tr>
</table>
</body>
</html>

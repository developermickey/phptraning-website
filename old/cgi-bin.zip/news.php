<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<table width="178" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td height="30"><table width="174" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td width="10">&nbsp;</td>
        <td width="164" height="32" valign="bottom" class="white1">NEWS &amp; EVENTS</td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td><marquee behavior="scroll" direction="up" scrollamount="2"  onmouseover="this.stop();" onmouseout="this.start();" height="150">
      <table width="179" border="0" align="center" cellpadding="0" cellspacing="0">
        <tr>
          <td><div align="justify" style="font-size:12px;font-weight:bold;line-height:15px">i)  NVIRON Training Program on “Water Conservation, Rainwater Harvesting & Ground Water Management” scheduled at Chandigarh on 22nd & 23rd June 2018.</div></td>
        </tr>
        <tr>
          <td><img src="images/dev.jpg" width="179" height="4" /></td>
        </tr>
        <tr>
          <td><div align="justify" style="font-size:12px;font-weight:bold;line-height:15px">ii) NVIRON Training Workshop on “Wastewater Treatment Plant Design, Operation & Maintenance and Troubleshooting” scheduled to held on 22nd & 23rd June 2018 at Indore.</div></td>
        </tr>
        <tr>
          <td><img src="images/dev.jpg" width="179" height="4" /></td>
        </tr>
        <tr>
          <td><div align="justify" style="font-size:12px;font-weight:bold;line-height:15px">iii) NVIRON Training Workshop on “Wastewater Treatment Plant Design, Operation & Maintenance and Troubleshooting” scheduled to held on 29th & 30th June 2018 at Bangalore.</div></td>
        </tr>
        <tr>
          <td><img src="images/dev.jpg" width="179" height="4" /></td>
        </tr>
        <tr>
          <td>&nbsp;</td>
        </tr>
      </table>
    </marquee></td>
  </tr>
</table>
</body>
</html>

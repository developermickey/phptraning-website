<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<table width="178" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td height="30"><table width="174" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td width="10">&nbsp;</td>
        <td width="164" height="30" valign="middle" class="white1">TESTIMONIALS</td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td><marquee behavior="scroll" direction="up" scrollamount="2"  onmouseover="this.stop();" onmouseout="this.start();" height="150">
      <table width="179" border="0" align="center" cellpadding="0" cellspacing="0">
        <tr>
          <td><div align="justify" style="font-size:12px;font-weight:bold;line-height:15px"><strong>i) Diganta Roy, Manager , Bharat Petroleum Corporation Limited – This training is up-to-date. Very Practical Faculties.</strong>
</div></td>
        </tr>
        <tr>
          <td><img src="images/dev.jpg" width="179" height="4" /></td>
        </tr>
        <tr>
          <td><div align="justify" style="font-size:12px;font-weight:bold;line-height:15px">	<strong>ii) Mustak Mulla, Assistant Manager, Mahanagar Gas Limited – This was an excellent session </strong>
</div></td>
        </tr>
       <tr>
          <td><img src="images/dev.jpg" width="179" height="4" /></td>
        </tr>
        <tr>
          <td><div align="justify" style="font-size:12px;font-weight:bold;line-height:15px"><strong>iii) Satish Rane, Manager, Bajaj Auto Limited – Very nice presentations & inputs</strong></div></td>
        </tr>
        <tr>
          <td><img src="images/dev.jpg" width="179" height="4" /></td>
        </tr>
        <tr>
          <td><div align="justify" style="font-size:12px;font-weight:bold;line-height:15px"><strong>iv) Sanjiv B. Pednekar , Manager , Godrej & Boyce Mfg. Co. Ltd. – Very good training program, information and engaging as well as interesting.</strong></div></td>
        </tr>
        <tr>
          <td><img src="images/dev.jpg" width="179" height="4" /></td>
        </tr>
        <tr>
          <td><div align="justify" style="font-size:12px;font-weight:bold;line-height:15px"><strong>v) Satish B Nagarale, Manager , Mylan Pharmaceuticals – I guess both the trainers are the subject matter expert & highly qualified. It was a fruitful session. Trainers were whelming & responding in a best technical & simpler way.</strong></div></td>
        </tr>
        <tr>
          <td><img src="images/dev.jpg" width="179" height="4" /></td>
        </tr>
        <tr>
          <td><div align="justify" style="font-size:12px;font-weight:bold;line-height:15px"><strong>vi) Aamir Alam, Co-Founder, Aquabright – It has been great learning experience. I have benefited by this training on subject matter.</strong></div></td>
        </tr>
        <tr>
          <td><img src="images/dev.jpg" width="179" height="4" /></td>
        </tr>
        <tr>
          <td><div align="justify" style="font-size:12px;font-weight:bold;line-height:15px"><strong>vii) Atul Tendulkar, General Manager, Matrix-K Raheja Group – Very fruitful session by the trainer. His immense knowledge and field experience kept the trainees glued to the session throughout. My sincere thanks and Best regards to him & NVIRON.</strong></div></td>
        </tr>
        <tr>
          <td><img src="images/dev.jpg" width="179" height="4" /></td>
        </tr>
        <tr>
          <td><div align="justify" style="font-size:12px;font-weight:bold;line-height:15px"><strong>viii) S, Vasudevan, Assistant Manager, Madras Fertilizers Limited – Very good lecture by the faculty. He is equipped with thorough knowledge. Very useful for the improvement of our plant.</strong></div></td>
        </tr>
        <tr>
          <td><img src="images/dev.jpg" width="179" height="4" /></td>
        </tr>
        <tr>
          <td><div align="justify" style="font-size:12px;font-weight:bold;line-height:15px"><strong>ix) Naresh Naik, Assistant Manager , Mahanadi Coalfields Limited – Training was very nice and trainer is very enthusiastic and informative. Clips on latest trends in wastewater technology was so helpful in updating knowledge.</strong></div></td>
        </tr>
        <tr>
          <td><img src="images/dev.jpg" width="179" height="4" /></td>
        </tr>
        <tr>
          <td><div align="justify" style="font-size:12px;font-weight:bold;line-height:15px"><strong>x) KR. Pritam Tiwary , Deputy Manager , Central Electronics – The conduct of training was very much fruitful and for our industry the inputs are very much beneficial.</strong></div></td>
        </tr>
      </table>
    </marquee></td>
  </tr>
</table>
</body>
</html>

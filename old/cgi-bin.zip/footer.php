<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<table width="1011" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="797" class="colorwhite">Copyright © <script>var d=new Date();document.write(d.getFullYear())</script> NVIRON Consulting Pvt. Ltd. All Rights Reserved.</td>
    <td width="214" align="right"><table width="129" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td width="97" class="colorwhite">Designed by :</td>
        <td width="53" align="right"><a href="http://www.adityahosting.com/" target="_blank"><img src="images/1.png" width="30" height="20" border="0" /></a></td>
      </tr>
    </table></td>
  </tr>
</table>
</body>
</html>

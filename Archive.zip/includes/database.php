<?php
//database.php
define("IHM_ADMIN", "ihm_admin");
define("IHM_ADMIN_LOGS", "ihm_admin_logs");

define("PAGES", "ihm_pages");
define("PAGE_CONTENTS", "ihm_page_contents");
define("MENU", "ihm_menus");

define("NOTIFICATION", "ihm_notices");
define("NEWS", "ihm_news");
define("EVENTS", "ihm_events");
define("ANNOUNCEMENT", "ihm_announcement");

define("PHOTO_CATEGORYS", "ihm_photo_category");
define("PHOTO_GALLERYS", "ihm_photo_gallery");
define("FACULTIES", "ihm_faculties");
define("HUNAR", "ihm_hunar");
define("TENDERS", "ihm_tenders");
define("TESTING", "tbl1_testimonial");
define("ATTORNEY", "tbl_attorney");

?>
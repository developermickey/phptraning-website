<?php
error_reporting(0);
define('SYSTEM_DBHOST', 'localhost');
define('SYSTEM_DBUSER', 'nviron_user');
define('SYSTEM_DBPWD', 'TSax0MfX(JGq');
define('SYSTEM_DBNAME', 'nviron_nvirondb');


define("SITE_HOME","https://www.nviron.in/");
define("URL_IMG",SITE_HOME."images/");
define("ADMIN_HOME",SITE_HOME."padmin/");

define("DIR_HOME","/home/ssst/");
define("DIR_IMAGES",DIR_HOME."images/");

define("ADMIN_EMAIL","anupam@nviron.in");
define("PAGE_TITLE","Welcome Nviron Solutions");
define('PAGE_LIMIT', 30);
define('SES', 'BB');

?>
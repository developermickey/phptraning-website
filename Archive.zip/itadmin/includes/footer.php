<div id="footer">
<div class="fleft">&nbsp; &nbsp;Copyright <script>var d=new Date();document.write(d.getFullYear())</script> NVIRON.</div>
<div class="fright">Powered by-&nbsp;<a href="http://www.ahws.in/" target="_blank" class="newslinkk13">AH Web Solutions</a> </div>
<div class="clear"></div>
</div>
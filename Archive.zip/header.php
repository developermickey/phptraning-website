     <div class="mean-bar">
         <div class="mobile-menu-nav-back">
             <a class="logo-mobile" href="https://www.nviron.in/">
                 <img src="img/logo.png" alt="NVIRON Training Centre Training and knowledge solution provider in the field of environment, health & safety" class="img-fluid">
                 </a>
                 <img src="img/nebosh.jpg"  alt="NVIRON Training Centre Training and knowledge solution provider in the field of environment, health & safety">
                 </div>
                 </div>
        
        <header>
        	<div class="header-area-top-area">
        		<div class="container">
        			<div class="row">
        				<div class="col-lg-6 col-md-6 col-sm-6 col-sm-12">
        					<div class="header-top-left">
        						<p><i class="fa fa-envelope"></i> anupam@nviron.in <span style="margin:0 5px;"><i class="fa fa-phone"></i>+91 9776763500</span>
                                <span style="margin:0 5px;display:none"><i class="fa fa-fax"></i>Fax 0671-244-2028</span></p>
                                <p class="pull-right"><a href="https://www.instamojo.com/@nvironconsultingpvtltd/?ref=onb_tasks" target="_blank" class="pay">Pay Online</a></p>
        					</div>
        				</div>
               				
        				<div class="col-lg-6 col-md-6 col-sm-6 col-sm-12">
                       <!-- <p class="pull-left" style="margin:0"><a href="index.php#midsection"  class="pay pay2">Customize Your Training Course</a></p>-->
                       <p class="pull-left" style="margin:0"><a href="upload/Training-Registration-Form.docx"  class="pay pay2">Training Registration Form</a>
        					<div class="header-top-right">
        						<nav>
        							<ul>
                                    <!--<span style="color:#fff">
                                    Go Social
                                    </span>-->
        								<li><a href="https://www.facebook.com/pages/NVIRON/362045860622202" target="_blank"><i class="fa fa-facebook"></i></a></li>
        								<li><a href="#" target="_blank" id="twitter"><i class="fa fa-twitter"></i></a></li>
                                        <li><a href="https://www.linkedin.com/company/nviron-consulting-pvt-ltd/" target="_blank" id="linkedin"><i class="fa fa-linkedin"></i></a></li>
                                        <li><a href="https://api.whatsapp.com/send?phone=918599066200" id="whatsapp" target="_blank"><i class="fa fa-whatsapp"></i></a></li>
                                         <li><a href="https://www.youtube.com/channel/UCRxDEqm-acnI6GDFXWzfWIQ" id="youtube" target="_blank"><i class="fa fa-youtube-play"></i></a></li>
        							</ul>
        						</nav>
        					</div>
        				</div>
        			</div>
        		</div>
        	</div>
            <div class="main-header-area">
                <div class="container">
                     <div class="">                         
                          <div class="col-lg-2 col-md-2 col-sm-12 col-sm-12" style="padding:0">
                              <div class="logo-area">
                                  <a href="https://www.nviron.in/"><img src="img/logo.png" alt="NVIRON Training Centre Training and knowledge solution provider in the field of environment, health & safety"></a>
                              </div>
                          </div>  
                          <div class="col-lg-8 col-md-8 col-sm-12 col-sm-12">
                                 <?php $menuObj->getMenuTree();?>  
                              
                          </div> 
                          <div class="col-lg-2 col-md-2 col-sm-12 col-sm-12" style="padding:0">
                              <img src="img/nebosh.jpg" alt="NVIRON Training Centre Training and knowledge solution provider in the field of environment, health & safety" style="padding-top: 3px;">
                          </div> 
                     </div>
                 </div> 
            </div>
            
            <!-- mobile-menu-area start -->
            <div class="mobile-menu-area">
              <div class="container">
              <div class="row">
                <div class="col-md-12">
                      <?php $menuObj->getMenuTreeone();?>      
                </div>
              </div>
              </div>
            </div>
            <!-- mobile-menu-area end -->
        </header>
        
                
         